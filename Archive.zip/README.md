Big Byte Challenge

Team Members:
  Ang Li
  Yaqi Zhang
  Sherry Liu

I am a README
