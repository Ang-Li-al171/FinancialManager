//
//  IconButton.h
//  FM
//
//  Created by Ang Li on 9/27/13.
//  Copyright (c) 2013 Duke CS. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "menuButton.h"

@interface IconButton : UICollectionViewCell
@property (weak, nonatomic) IBOutlet menuButton *myButton;

@end
