//
//  CollectionFlowLayout.h
//  FM
//
//  Created by Ang Li on 9/28/13.
//  Copyright (c) 2013 Duke CS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CollectionFlowLayout : UICollectionViewFlowLayout <UICollectionViewDelegateFlowLayout>

@end
