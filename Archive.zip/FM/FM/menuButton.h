//
//  menuButton.h
//  FM
//
//  Created by Ang Li on 9/29/13.
//  Copyright (c) 2013 Duke CS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface menuButton : UIButton

@property int myRowNum;
- (void) setRowNum: (int) num;

@end
