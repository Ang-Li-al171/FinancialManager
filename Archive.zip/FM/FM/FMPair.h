//
//  FMPair.h
//  FM
//
//  Created by  mac on 9/28/13.
//  Copyright (c) 2013 Duke CS. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Foundation/Foundation.h>

@interface FMPair : NSObject

@property int paid;
@property int shouldPay;

@end
